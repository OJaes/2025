package Test;

public interface Vehicle {
	void accelerate();
	void stop();
	void setStart();
	
}
